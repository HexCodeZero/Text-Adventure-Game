import java.util.*;
import java.io.*;
import java.lang.*;

class Main {
  public static void main(String[] args) {
    Game game = new Game();
  }
}